import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, Trash2, Plus, Minus, ShoppingCart, User, X } from "lucide-react";
import { Link } from "wouter";

interface CartItem {
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export default function POS() {
  const { user } = useAuth();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [barcode, setBarcode] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState("نقدي");
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState("");
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  const utils = trpc.useUtils();
  const { mutate: createSale, isPending: isCreatingSale } = trpc.sales.create.useMutation({
    onSuccess: () => {
      toast.success("تمت عملية البيع بنجاح");
      setCart([]);
      setSelectedCustomer(null);
      setCustomerPhone("");
      setPaymentMethod("نقدي");
      utils.products.list.invalidate();
      barcodeInputRef.current?.focus();
    },
    onError: (error) => {
      toast.error("فشلت عملية البيع: " + error.message);
    },
  });

  const { mutate: createCustomer } = trpc.customers.create.useMutation({
    onSuccess: (customerId) => {
      toast.success("تم إضافة العميل بنجاح");
      setShowCustomerDialog(false);
      utils.customers.getByPhone.invalidate();
    },
    onError: (error) => {
      toast.error("فشل إضافة العميل: " + error.message);
    },
  });

  const handleBarcodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcode.trim()) return;

    try {
      const product = await utils.client.products.getByBarcode.query({ barcodeId: barcode });
      
      if (!product) {
        toast.error("المنتج غير موجود");
        setBarcode("");
        return;
      }

      if (product.stockQuantity <= 0) {
        toast.error("المنتج غير متوفر في المخزون");
        setBarcode("");
        return;
      }

      const existingItem = cart.find(item => item.productId === product.id);
      
      if (existingItem) {
        if (existingItem.quantity >= product.stockQuantity) {
          toast.error("الكمية المطلوبة تتجاوز المخزون المتاح");
          setBarcode("");
          return;
        }
        updateQuantity(product.id, existingItem.quantity + 1);
      } else {
        const newItem: CartItem = {
          productId: product.id,
          productName: product.productName,
          quantity: 1,
          unitPrice: product.retailPrice / 100,
          total: product.retailPrice / 100,
        };
        setCart([...cart, newItem]);
      }
      
      setBarcode("");
      toast.success("تمت إضافة المنتج");
    } catch (error) {
      toast.error("حدث خطأ في البحث عن المنتج");
      setBarcode("");
    }
  };

  const handleCustomerLookup = async () => {
    if (!customerPhone.trim()) return;

    try {
      const customer = await utils.client.customers.getByPhone.query({ phone: customerPhone });
      
      if (customer) {
        setSelectedCustomer(customer);
        toast.success("تم العثور على العميل: " + customer.customerName);
      } else {
        setShowCustomerDialog(true);
      }
    } catch (error) {
      toast.error("حدث خطأ في البحث عن العميل");
    }
  };

  const handleAddNewCustomer = () => {
    if (!newCustomerName.trim()) {
      toast.error("الرجاء إدخال اسم العميل");
      return;
    }

    createCustomer({
      customerName: newCustomerName,
      phone: customerPhone,
    });
    
    setNewCustomerName("");
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(productId);
      return;
    }

    setCart(cart.map(item => {
      if (item.productId === productId) {
        return {
          ...item,
          quantity: newQuantity,
          total: item.unitPrice * newQuantity,
        };
      }
      return item;
    }));
  };

  const removeItem = (productId: number) => {
    setCart(cart.filter(item => item.productId !== productId));
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + item.total, 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    const totalAmount = Math.round(calculateTotal() * 100); // Convert to fils
    const items = cart.map(item => ({
      productId: item.productId,
      quantity: item.quantity,
      unitPriceAtSale: Math.round(item.unitPrice * 100),
      lineTotal: Math.round(item.total * 100),
    }));

    createSale({
      totalAmount,
      paymentMethod,
      customerId: selectedCustomer?.id,
      items,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-white border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">نقطة البيع</h1>
            <Link href="/">
              <Button variant="outline">العودة للرئيسية</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Product Entry & Customer */}
          <div className="lg:col-span-2 space-y-6">
            {/* Barcode Scanner */}
            <Card>
              <CardHeader>
                <CardTitle>مسح الباركود</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBarcodeSubmit} className="flex gap-2">
                  <Input
                    ref={barcodeInputRef}
                    type="text"
                    placeholder="امسح أو أدخل الباركود"
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    className="text-lg"
                    autoFocus
                  />
                  <Button type="submit">إضافة</Button>
                </form>
              </CardContent>
            </Card>

            {/* Customer Lookup */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  معلومات العميل
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedCustomer ? (
                  <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium">{selectedCustomer.customerName}</p>
                      <p className="text-sm text-muted-foreground">{selectedCustomer.phone}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedCustomer(null);
                        setCustomerPhone("");
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input
                      type="tel"
                      placeholder="رقم الهاتف"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      dir="ltr"
                    />
                    <Button onClick={handleCustomerLookup} variant="outline">
                      بحث
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Cart Items */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  السلة ({cart.length} منتج)
                </CardTitle>
              </CardHeader>
              <CardContent>
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">السلة فارغة</p>
                ) : (
                  <div className="space-y-2">
                    {cart.map((item) => (
                      <div key={item.productId} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{item.productName}</p>
                          <p className="text-sm text-muted-foreground">
                            {item.unitPrice.toFixed(2)} ريال × {item.quantity}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 bg-background rounded px-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="font-bold w-20 text-left">{item.total.toFixed(2)} ريال</p>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.productId)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Checkout */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>إتمام البيع</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>طريقة الدفع</Label>
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="نقدي">نقدي</SelectItem>
                      <SelectItem value="بطاقة">بطاقة</SelectItem>
                      <SelectItem value="تحويل">تحويل بنكي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>عدد المنتجات:</span>
                    <span>{cart.reduce((sum, item) => sum + item.quantity, 0)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold">
                    <span>الإجمالي:</span>
                    <span>{calculateTotal().toFixed(2)} ريال</span>
                  </div>
                </div>

                <Button
                  className="w-full"
                  size="lg"
                  onClick={handleCheckout}
                  disabled={cart.length === 0 || isCreatingSale}
                >
                  {isCreatingSale ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جاري المعالجة...
                    </>
                  ) : (
                    "إتمام البيع"
                  )}
                </Button>

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setCart([])}
                  disabled={cart.length === 0}
                >
                  مسح السلة
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* New Customer Dialog */}
      <Dialog open={showCustomerDialog} onOpenChange={setShowCustomerDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة عميل جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>رقم الهاتف</Label>
              <Input value={customerPhone} disabled dir="ltr" />
            </div>
            <div>
              <Label>اسم العميل</Label>
              <Input
                value={newCustomerName}
                onChange={(e) => setNewCustomerName(e.target.value)}
                placeholder="أدخل اسم العميل"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCustomerDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleAddNewCustomer}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
