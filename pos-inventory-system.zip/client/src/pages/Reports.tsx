import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { Receipt, TrendingUp, Package, DollarSign, AlertCircle } from "lucide-react";

export default function Reports() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const { data: products } = trpc.products.list.useQuery();
  const { data: expenses } = trpc.expenses.list.useQuery(undefined, {
    enabled: user?.role === 'admin',
  });

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">غير مصرح لك بالوصول لهذه الصفحة</p>
            <Button className="w-full mt-4" onClick={() => setLocation("/")}>
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const lowStockProducts = products?.filter(p => p.stockQuantity <= (p.reorderLevel || 0)) || [];
  const totalInventoryValue = products?.reduce((sum, p) => sum + (p.costPrice * p.stockQuantity), 0) || 0;
  const totalExpenses = expenses?.reduce((sum, e) => sum + e.amount, 0) || 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-white border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Receipt className="h-6 w-6" />
              التقارير والتحليلات
            </h1>
            <Link href="/">
              <Button variant="outline">العودة للرئيسية</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">قيمة المخزون</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(totalInventoryValue / 100).toFixed(2)} ريال</div>
              <p className="text-xs text-muted-foreground">إجمالي قيمة المخزون</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المصروفات</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(totalExpenses / 100).toFixed(2)} ريال</div>
              <p className="text-xs text-muted-foreground">إجمالي المصروفات</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المبيعات</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0.00 ريال</div>
              <p className="text-xs text-muted-foreground">إجمالي المبيعات</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الربح/الخسارة</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0.00 ريال</div>
              <p className="text-xs text-muted-foreground">صافي الربح</p>
            </CardContent>
          </Card>
        </div>

        {/* Reports Tabs */}
        <Tabs defaultValue="inventory" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="inventory">المخزون</TabsTrigger>
            <TabsTrigger value="sales">المبيعات</TabsTrigger>
            <TabsTrigger value="expenses">المصروفات</TabsTrigger>
            <TabsTrigger value="profit">الأرباح والخسائر</TabsTrigger>
          </TabsList>

          {/* Inventory Report */}
          <TabsContent value="inventory" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>تقرير المخزون</CardTitle>
                <CardDescription>حالة المخزون الحالية</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-lg">
                    <div>
                      <p className="text-sm text-muted-foreground">إجمالي المنتجات</p>
                      <p className="text-2xl font-bold">{products?.length || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">منتجات نشطة</p>
                      <p className="text-2xl font-bold">{products?.filter(p => p.isActive).length || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">مخزون منخفض</p>
                      <p className="text-2xl font-bold text-destructive">{lowStockProducts.length}</p>
                    </div>
                  </div>

                  {lowStockProducts.length > 0 && (
                    <div>
                      <h3 className="font-semibold mb-3 flex items-center gap-2">
                        <AlertCircle className="h-5 w-5 text-destructive" />
                        منتجات تحتاج إعادة طلب
                      </h3>
                      <div className="space-y-2">
                        {lowStockProducts.map(product => (
                          <div key={product.id} className="flex justify-between items-center p-3 bg-muted rounded">
                            <div>
                              <p className="font-medium">{product.productName}</p>
                              <p className="text-sm text-muted-foreground">الباركود: {product.barcodeId}</p>
                            </div>
                            <div className="text-left">
                              <p className="text-sm text-muted-foreground">الكمية الحالية</p>
                              <p className="font-bold text-destructive">{product.stockQuantity}</p>
                              <p className="text-xs text-muted-foreground">حد الطلب: {product.reorderLevel}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sales Report */}
          <TabsContent value="sales" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>تقرير المبيعات</CardTitle>
                <CardDescription>تحليل المبيعات حسب الفترة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>من تاريخ</Label>
                      <Input
                        type="date"
                        value={dateFrom}
                        onChange={(e) => setDateFrom(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>إلى تاريخ</Label>
                      <Input
                        type="date"
                        value={dateTo}
                        onChange={(e) => setDateTo(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button className="w-full">عرض التقرير</Button>
                  
                  <div className="text-center py-8 text-muted-foreground">
                    لا توجد مبيعات في الفترة المحددة
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Expenses Report */}
          <TabsContent value="expenses" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>تقرير المصروفات</CardTitle>
                <CardDescription>تحليل المصروفات حسب الفئة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">إجمالي المصروفات</p>
                    <p className="text-3xl font-bold">{(totalExpenses / 100).toFixed(2)} ريال</p>
                  </div>

                  {expenses && expenses.length > 0 ? (
                    <div className="space-y-2">
                      {expenses.slice(0, 10).map(expense => (
                        <div key={expense.id} className="flex justify-between items-center p-3 bg-muted rounded">
                          <div>
                            <p className="font-medium">{expense.description || 'مصروف'}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(expense.expenseDate).toLocaleDateString('ar-SA')}
                            </p>
                          </div>
                          <p className="font-bold">{(expense.amount / 100).toFixed(2)} ريال</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      لا توجد مصروفات مسجلة
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profit & Loss Report */}
          <TabsContent value="profit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>تقرير الأرباح والخسائر</CardTitle>
                <CardDescription>تحليل الأداء المالي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between p-3 bg-green-50 rounded">
                      <span className="font-medium">إجمالي المبيعات</span>
                      <span className="font-bold text-green-600">0.00 ريال</span>
                    </div>
                    <div className="flex justify-between p-3 bg-red-50 rounded">
                      <span className="font-medium">تكلفة البضاعة المباعة</span>
                      <span className="font-bold text-red-600">0.00 ريال</span>
                    </div>
                    <div className="flex justify-between p-3 bg-muted rounded">
                      <span className="font-medium">مجمل الربح</span>
                      <span className="font-bold">0.00 ريال</span>
                    </div>
                    <div className="flex justify-between p-3 bg-red-50 rounded">
                      <span className="font-medium">المصروفات التشغيلية</span>
                      <span className="font-bold text-red-600">{(totalExpenses / 100).toFixed(2)} ريال</span>
                    </div>
                    <div className="flex justify-between p-4 bg-primary/10 rounded-lg border-2 border-primary">
                      <span className="font-bold text-lg">صافي الربح/الخسارة</span>
                      <span className="font-bold text-lg text-destructive">
                        -{(totalExpenses / 100).toFixed(2)} ريال
                      </span>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">ملاحظات:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>التقرير يعرض البيانات المتراكمة منذ بداية النظام</li>
                      <li>يمكن تصفية البيانات حسب فترة زمنية محددة</li>
                      <li>يتم احتساب تكلفة البضاعة بناءً على سعر التكلفة المسجل</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
