import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, Plus, DollarSign } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Expenses() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showDialog, setShowDialog] = useState(false);

  const [formData, setFormData] = useState({
    categoryId: "",
    amount: "",
    description: "",
    reference: "",
    expenseDate: new Date().toISOString().split('T')[0],
  });

  const { data: expenses, isLoading } = trpc.expenses.list.useQuery(undefined, {
    enabled: user?.role === 'admin',
  });
  const { data: categories } = trpc.expenseCategories.list.useQuery(undefined, {
    enabled: user?.role === 'admin',
  });
  const utils = trpc.useUtils();

  const { mutate: createExpense, isPending: isCreating } = trpc.expenses.create.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة المصروف بنجاح");
      setShowDialog(false);
      resetForm();
      utils.expenses.list.invalidate();
    },
    onError: (error) => {
      toast.error("فشل إضافة المصروف: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({
      categoryId: "",
      amount: "",
      description: "",
      reference: "",
      expenseDate: new Date().toISOString().split('T')[0],
    });
  };

  const handleSubmit = () => {
    if (!formData.categoryId || !formData.amount) {
      toast.error("الرجاء ملء الحقول المطلوبة");
      return;
    }

    createExpense({
      categoryId: parseInt(formData.categoryId),
      amount: Math.round(parseFloat(formData.amount) * 100),
      description: formData.description,
      reference: formData.reference,
      expenseDate: new Date(formData.expenseDate),
    });
  };

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">غير مصرح لك بالوصول لهذه الصفحة</p>
            <Button className="w-full mt-4" onClick={() => setLocation("/")}>
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalExpenses = expenses?.reduce((sum, e) => sum + e.amount, 0) || 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-white border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <DollarSign className="h-6 w-6" />
              إدارة المصروفات
            </h1>
            <Link href="/">
              <Button variant="outline">العودة للرئيسية</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Summary Card */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي المصروفات</p>
                <p className="text-3xl font-bold">{(totalExpenses / 100).toFixed(2)} ريال</p>
              </div>
              <Button onClick={() => setShowDialog(true)}>
                <Plus className="ml-2 h-4 w-4" />
                إضافة مصروف
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Expenses Table */}
        <Card>
          <CardHeader>
            <CardTitle>سجل المصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الفئة</TableHead>
                    <TableHead>الوصف</TableHead>
                    <TableHead>المرجع</TableHead>
                    <TableHead>المبلغ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {!expenses || expenses.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground">
                        لا توجد مصروفات مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    expenses.map((expense) => {
                      const category = categories?.find(c => c.id === expense.categoryId);
                      return (
                        <TableRow key={expense.id}>
                          <TableCell>
                            {new Date(expense.expenseDate).toLocaleDateString('ar-SA')}
                          </TableCell>
                          <TableCell>{category?.categoryName || '-'}</TableCell>
                          <TableCell>{expense.description || '-'}</TableCell>
                          <TableCell>{expense.reference || '-'}</TableCell>
                          <TableCell className="font-bold">
                            {(expense.amount / 100).toFixed(2)} ريال
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Add Expense Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة مصروف جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>التاريخ *</Label>
              <Input
                type="date"
                value={formData.expenseDate}
                onChange={(e) => setFormData({ ...formData, expenseDate: e.target.value })}
              />
            </div>
            <div>
              <Label>الفئة *</Label>
              <Select value={formData.categoryId} onValueChange={(value) => setFormData({ ...formData, categoryId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.categoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>المبلغ (ريال) *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="0.00"
                dir="ltr"
              />
            </div>
            <div>
              <Label>الوصف</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="وصف المصروف"
                rows={3}
              />
            </div>
            <div>
              <Label>المرجع</Label>
              <Input
                value={formData.reference}
                onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
                placeholder="رقم الفاتورة أو المرجع"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSubmit} disabled={isCreating}>
              {isCreating ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                "إضافة"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
