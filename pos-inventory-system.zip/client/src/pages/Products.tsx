import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, Plus, Edit, Package, AlertCircle } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Products() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showDialog, setShowDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const [formData, setFormData] = useState({
    productName: "",
    barcodeId: "",
    supplierId: "",
    retailPrice: "",
    costPrice: "",
    stockQuantity: "",
    reorderLevel: "",
  });

  const { data: products, isLoading } = trpc.products.list.useQuery();
  const { data: suppliers } = trpc.suppliers.list.useQuery();
  const utils = trpc.useUtils();

  const { mutate: createProduct, isPending: isCreating } = trpc.products.create.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة المنتج بنجاح");
      setShowDialog(false);
      resetForm();
      utils.products.list.invalidate();
    },
    onError: (error) => {
      toast.error("فشل إضافة المنتج: " + error.message);
    },
  });

  const { mutate: updateProduct, isPending: isUpdating } = trpc.products.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث المنتج بنجاح");
      setShowDialog(false);
      setEditingProduct(null);
      resetForm();
      utils.products.list.invalidate();
    },
    onError: (error) => {
      toast.error("فشل تحديث المنتج: " + error.message);
    },
  });

  const resetForm = () => {
    setFormData({
      productName: "",
      barcodeId: "",
      supplierId: "",
      retailPrice: "",
      costPrice: "",
      stockQuantity: "",
      reorderLevel: "",
    });
  };

  const handleOpenDialog = (product?: any) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        productName: product.productName,
        barcodeId: product.barcodeId,
        supplierId: product.supplierId.toString(),
        retailPrice: (product.retailPrice / 100).toString(),
        costPrice: (product.costPrice / 100).toString(),
        stockQuantity: product.stockQuantity.toString(),
        reorderLevel: product.reorderLevel?.toString() || "",
      });
    } else {
      setEditingProduct(null);
      resetForm();
    }
    setShowDialog(true);
  };

  const handleSubmit = () => {
    if (!formData.productName || !formData.barcodeId || !formData.supplierId || !formData.retailPrice || !formData.costPrice) {
      toast.error("الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    const data = {
      productName: formData.productName,
      barcodeId: formData.barcodeId,
      supplierId: parseInt(formData.supplierId),
      retailPrice: Math.round(parseFloat(formData.retailPrice) * 100),
      costPrice: Math.round(parseFloat(formData.costPrice) * 100),
      stockQuantity: parseInt(formData.stockQuantity) || 0,
      reorderLevel: parseInt(formData.reorderLevel) || 0,
    };

    if (editingProduct) {
      updateProduct({ id: editingProduct.id, ...data });
    } else {
      createProduct(data);
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">غير مصرح لك بالوصول لهذه الصفحة</p>
            <Button className="w-full mt-4" onClick={() => setLocation("/")}>
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredProducts = products?.filter(p =>
    p.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.barcodeId.includes(searchTerm)
  ) || [];

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-white border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Package className="h-6 w-6" />
              إدارة المنتجات
            </h1>
            <Link href="/">
              <Button variant="outline">العودة للرئيسية</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>قائمة المنتجات</CardTitle>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="ml-2 h-4 w-4" />
                إضافة منتج
              </Button>
            </div>
            <div className="mt-4">
              <Input
                placeholder="بحث بالاسم أو الباركود..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>اسم المنتج</TableHead>
                    <TableHead>الباركود</TableHead>
                    <TableHead>سعر البيع</TableHead>
                    <TableHead>سعر التكلفة</TableHead>
                    <TableHead>المخزون</TableHead>
                    <TableHead>حد الطلب</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                        لا توجد منتجات
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredProducts.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell className="font-medium">{product.productName}</TableCell>
                        <TableCell dir="ltr">{product.barcodeId}</TableCell>
                        <TableCell>{(product.retailPrice / 100).toFixed(2)} ريال</TableCell>
                        <TableCell>{(product.costPrice / 100).toFixed(2)} ريال</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {product.stockQuantity}
                            {product.stockQuantity <= (product.reorderLevel || 0) && (
                              <AlertCircle className="h-4 w-4 text-destructive" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{product.reorderLevel || 0}</TableCell>
                        <TableCell>
                          <Badge variant={product.isActive ? "default" : "secondary"}>
                            {product.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleOpenDialog(product)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Add/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "تعديل منتج" : "إضافة منتج جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>اسم المنتج *</Label>
              <Input
                value={formData.productName}
                onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                placeholder="أدخل اسم المنتج"
              />
            </div>
            <div>
              <Label>الباركود *</Label>
              <Input
                value={formData.barcodeId}
                onChange={(e) => setFormData({ ...formData, barcodeId: e.target.value })}
                placeholder="أدخل الباركود"
                dir="ltr"
              />
            </div>
            <div>
              <Label>المورد *</Label>
              <Select value={formData.supplierId} onValueChange={(value) => setFormData({ ...formData, supplierId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر المورد" />
                </SelectTrigger>
                <SelectContent>
                  {suppliers?.map((supplier) => (
                    <SelectItem key={supplier.id} value={supplier.id.toString()}>
                      {supplier.supplierName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>سعر البيع (ريال) *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.retailPrice}
                onChange={(e) => setFormData({ ...formData, retailPrice: e.target.value })}
                placeholder="0.00"
                dir="ltr"
              />
            </div>
            <div>
              <Label>سعر التكلفة (ريال) *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.costPrice}
                onChange={(e) => setFormData({ ...formData, costPrice: e.target.value })}
                placeholder="0.00"
                dir="ltr"
              />
            </div>
            <div>
              <Label>الكمية في المخزون</Label>
              <Input
                type="number"
                value={formData.stockQuantity}
                onChange={(e) => setFormData({ ...formData, stockQuantity: e.target.value })}
                placeholder="0"
                dir="ltr"
              />
            </div>
            <div>
              <Label>حد إعادة الطلب</Label>
              <Input
                type="number"
                value={formData.reorderLevel}
                onChange={(e) => setFormData({ ...formData, reorderLevel: e.target.value })}
                placeholder="0"
                dir="ltr"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSubmit} disabled={isCreating || isUpdating}>
              {(isCreating || isUpdating) ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                editingProduct ? "تحديث" : "إضافة"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
