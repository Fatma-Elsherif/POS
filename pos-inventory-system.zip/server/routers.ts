import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Suppliers
  suppliers: router({
    list: protectedProcedure.query(async () => {
      const { getAllSuppliers } = await import('./db');
      return await getAllSuppliers();
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const { getSupplierById } = await import('./db');
      return await getSupplierById(input.id);
    }),
    create: protectedProcedure.input(z.object({
      supplierName: z.string(),
      contactName: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      address: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { createSupplier } = await import('./db');
      return await createSupplier(input);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      supplierName: z.string().optional(),
      contactName: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      address: z.string().optional(),
      isActive: z.number().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { id, ...data } = input;
      const { updateSupplier } = await import('./db');
      await updateSupplier(id, data);
      return { success: true };
    }),
  }),

  // Products
  products: router({
    list: protectedProcedure.query(async () => {
      const { getAllProducts } = await import('./db');
      return await getAllProducts();
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const { getProductById } = await import('./db');
      return await getProductById(input.id);
    }),
    getByBarcode: protectedProcedure.input(z.object({ barcodeId: z.string() })).query(async ({ input }) => {
      const { getProductByBarcode } = await import('./db');
      return await getProductByBarcode(input.barcodeId);
    }),
    create: protectedProcedure.input(z.object({
      productName: z.string(),
      barcodeId: z.string(),
      supplierId: z.number(),
      retailPrice: z.number(),
      costPrice: z.number(),
      stockQuantity: z.number().default(0),
      reorderLevel: z.number().optional(),
      imageUrl: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { createProduct } = await import('./db');
      return await createProduct({ ...input, createdByUserId: ctx.user.id });
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      productName: z.string().optional(),
      barcodeId: z.string().optional(),
      supplierId: z.number().optional(),
      retailPrice: z.number().optional(),
      costPrice: z.number().optional(),
      stockQuantity: z.number().optional(),
      reorderLevel: z.number().optional(),
      imageUrl: z.string().optional(),
      isActive: z.number().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { id, ...data } = input;
      const { updateProduct } = await import('./db');
      await updateProduct(id, data);
      return { success: true };
    }),
  }),

  // Customers
  customers: router({
    list: protectedProcedure.query(async () => {
      const { getAllCustomers } = await import('./db');
      return await getAllCustomers();
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const { getCustomerById } = await import('./db');
      return await getCustomerById(input.id);
    }),
    getByPhone: protectedProcedure.input(z.object({ phone: z.string() })).query(async ({ input }) => {
      const { getCustomerByPhone } = await import('./db');
      return await getCustomerByPhone(input.phone);
    }),
    create: protectedProcedure.input(z.object({
      customerName: z.string(),
      phone: z.string(),
      email: z.string().optional(),
      address: z.string().optional(),
    })).mutation(async ({ input }) => {
      const { createCustomer } = await import('./db');
      return await createCustomer(input);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      customerName: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      address: z.string().optional(),
      isActive: z.number().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      const { updateCustomer } = await import('./db');
      await updateCustomer(id, data);
      return { success: true };
    }),
  }),

  // Sales
  sales: router({
    create: protectedProcedure.input(z.object({
      totalAmount: z.number(),
      paymentMethod: z.string(),
      customerId: z.number().optional(),
      items: z.array(z.object({
        productId: z.number(),
        quantity: z.number(),
        unitPriceAtSale: z.number(),
        lineTotal: z.number(),
      })),
    })).mutation(async ({ input, ctx }) => {
      const { createSale } = await import('./db');
      const { items, ...saleData } = input;
      const detailsForSale = items.map(item => ({
        ...item,
        saleId: 0 // Placeholder, will be set in createSale
      }));
      return await createSale(
        { ...saleData, userId: ctx.user.id },
        detailsForSale
      );
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const { getSaleById, getSaleDetails } = await import('./db');
      const sale = await getSaleById(input.id);
      if (!sale) return null;
      const details = await getSaleDetails(input.id);
      return { ...sale, details };
    }),
  }),

  // Expense Categories
  expenseCategories: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { getAllExpenseCategories } = await import('./db');
      return await getAllExpenseCategories();
    }),
    create: protectedProcedure.input(z.object({
      categoryName: z.string(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { createExpenseCategory } = await import('./db');
      return await createExpenseCategory(input);
    }),
  }),

  // Expenses
  expenses: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { getAllExpenses } = await import('./db');
      return await getAllExpenses();
    }),
    create: protectedProcedure.input(z.object({
      expenseDate: z.date(),
      categoryId: z.number(),
      amount: z.number(),
      description: z.string().optional(),
      reference: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
      const { createExpense } = await import('./db');
      return await createExpense({ ...input, userId: ctx.user.id });
    }),
  }),
});

export type AppRouter = typeof appRouter;
