CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customer_name` varchar(100) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(50),
	`address` text,
	`is_active` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_phone_unique` UNIQUE(`phone`)
);
--> statement-breakpoint
CREATE TABLE `expense_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`category_name` varchar(255) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `expense_categories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`expense_date` timestamp NOT NULL DEFAULT (now()),
	`category_id` int NOT NULL,
	`amount` int NOT NULL,
	`description` text,
	`reference` varchar(255),
	`user_id` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`barcode_id` varchar(50) NOT NULL,
	`supplier_id` int NOT NULL,
	`retail_price` int NOT NULL,
	`cost_price` int NOT NULL,
	`stock_quantity` int NOT NULL DEFAULT 0,
	`reorder_level` int DEFAULT 0,
	`image_url` varchar(500),
	`is_active` int NOT NULL DEFAULT 1,
	`created_by_user_id` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_barcode_id_unique` UNIQUE(`barcode_id`)
);
--> statement-breakpoint
CREATE TABLE `sale_details` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sale_id` int NOT NULL,
	`product_id` int NOT NULL,
	`quantity` int NOT NULL,
	`unit_price_at_sale` int NOT NULL,
	`line_total` int NOT NULL,
	CONSTRAINT `sale_details_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sale_date` timestamp NOT NULL DEFAULT (now()),
	`total_amount` int NOT NULL,
	`payment_method` varchar(50),
	`user_id` int NOT NULL,
	`customer_id` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sales_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`supplier_name` varchar(255) NOT NULL,
	`contact_name` varchar(255),
	`phone` varchar(50),
	`email` varchar(255),
	`address` text,
	`is_active` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
