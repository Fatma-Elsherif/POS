import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Suppliers table
export const suppliers = mysqlTable("suppliers", {
  id: int("id").autoincrement().primaryKey(),
  supplierName: varchar("supplier_name", { length: 255 }).notNull(),
  contactName: varchar("contact_name", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  address: text("address"),
  isActive: int("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = typeof suppliers.$inferInsert;

// Products table
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  barcodeId: varchar("barcode_id", { length: 50 }).notNull().unique(),
  supplierId: int("supplier_id").notNull(),
  retailPrice: int("retail_price").notNull(), // Store in cents/fils
  costPrice: int("cost_price").notNull(), // Store in cents/fils
  stockQuantity: int("stock_quantity").default(0).notNull(),
  reorderLevel: int("reorder_level").default(0),
  imageUrl: varchar("image_url", { length: 500 }),
  isActive: int("is_active").default(1).notNull(),
  createdByUserId: int("created_by_user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

// Customers table
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  customerName: varchar("customer_name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull().unique(),
  email: varchar("email", { length: 50 }),
  address: text("address"),
  isActive: int("is_active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

// Sales table
export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  saleDate: timestamp("sale_date").defaultNow().notNull(),
  totalAmount: int("total_amount").notNull(), // Store in cents/fils
  paymentMethod: varchar("payment_method", { length: 50 }),
  userId: int("user_id").notNull(),
  customerId: int("customer_id"), // Nullable for anonymous sales
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;

// Sale Details table
export const saleDetails = mysqlTable("sale_details", {
  id: int("id").autoincrement().primaryKey(),
  saleId: int("sale_id").notNull(),
  productId: int("product_id").notNull(),
  quantity: int("quantity").notNull(),
  unitPriceAtSale: int("unit_price_at_sale").notNull(), // Store in cents/fils
  lineTotal: int("line_total").notNull(), // Store in cents/fils
});

export type SaleDetail = typeof saleDetails.$inferSelect;
export type InsertSaleDetail = typeof saleDetails.$inferInsert;

// Expense Categories table
export const expenseCategories = mysqlTable("expense_categories", {
  id: int("id").autoincrement().primaryKey(),
  categoryName: varchar("category_name", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ExpenseCategory = typeof expenseCategories.$inferSelect;
export type InsertExpenseCategory = typeof expenseCategories.$inferInsert;

// Expenses table
export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  expenseDate: timestamp("expense_date").defaultNow().notNull(),
  categoryId: int("category_id").notNull(),
  amount: int("amount").notNull(), // Store in cents/fils
  description: text("description"),
  reference: varchar("reference", { length: 255 }),
  userId: int("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;